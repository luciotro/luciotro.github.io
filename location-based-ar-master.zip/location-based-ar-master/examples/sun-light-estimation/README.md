to use the position of the sun as a way to do light estimation
could even use the weather prediction for that.

- if cloudy, make the light dimmer

# Demo idea
"Show be the sun behind the cloud"


# Useful links
- https://developer.mozilla.org/en-US/docs/Web/API/Geolocation/getCurrentPosition
- https://github.com/mourner/suncalc
- http://curious.astro.cornell.edu/about-us/112-observational-astronomy/stargazing/technical-questions/698-what-are-altitude-and-azimuth-intermediate
