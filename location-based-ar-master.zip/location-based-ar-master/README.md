# Experimentation with GPS for AR

This is an experimentation of using phone gps + gyroscope to display Augmented reality.

Note: GPS accuracy is significantly less than normal AR tracking. So be sure 
it matches your use-case.

Note2: this is very experimental and not finished.

# Credit
It is based on the discussion from this [github issue](https://github.com/jeromeetienne/AR.js/issues/190).
It has been originated by [1d10t](https://github.com/1d10t) in this [file](https://1d10t.github.io/test/phills-sphere.html).
Thanks a LOT for your contribution!
